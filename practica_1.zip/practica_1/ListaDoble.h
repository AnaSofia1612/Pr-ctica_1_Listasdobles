#ifndef LISTADOBLE_H
#define LISTADOBLE_H

#include "Nodo.h"
#include <string>

class ListaDoble {
private:
    Nodo* cabeza; // Primer nodo (head)
    Nodo* cola;   // Último nodo (tail)

public:
    // Constructor
    ListaDoble();

    // Destructor para liberar memoria
    ~ListaDoble();

    // Cargar lista desde archivo de texto
    void cargarDesdeArchivo(const std::string &nombreArchivo);

    // Guardar lista en archivo de texto
    void guardarEnArchivo(const std::string &nombreArchivo);

    // Insertar un nuevo huésped
    void insertarHuesped(const std::string &nombre, int habitacion);

    // Buscar huésped por nombre
    Nodo* buscarPorNombre(const std::string &nombre);

    // Buscar huésped por número de habitación
    Nodo* buscarPorHabitacion(int habitacion);

    // Verificar si una habitación está ocupada
    bool habitacionOcupada(int habitacion);

    // Mostrar lista en orden de llegada
    void mostrarPorLlegada();

    // Mostrar lista en orden alfabético
    void mostrarAlfabetico();

    // Consultar vecinos de una habitación
    void consultarVecinos(int habitacion);

    // Liberar memoria de todos los nodos
    void limpiarLista();
};

#endif // LISTADOBLE_H
