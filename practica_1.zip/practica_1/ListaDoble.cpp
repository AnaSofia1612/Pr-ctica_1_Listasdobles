#include "ListaDoble.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

//Para que acepte tanto minusculas como mayusculas
string aMinusculas(string texto) {
    string resultado = texto;
    for (char &c : resultado) {
        c = tolower(static_cast<unsigned char>(c));
    }
    return resultado;
}

// Constructor
ListaDoble::ListaDoble() {
    cabeza = nullptr;
    cola = nullptr;
}

// Destructor
ListaDoble::~ListaDoble() {
    Nodo* actual = cabeza;
    while (actual) {
        Nodo* temp = actual;
        actual = actual->siguiente;
        delete temp;
    }
}

// Insertar huésped al final
void ListaDoble::insertarHuesped(const string &nombre, int habitacion) {
    Nodo* nuevo = new Nodo(nombre, habitacion);
    if (!cabeza) { // lista vacía
        cabeza = cola = nuevo;
    } else {
        cola->siguiente = nuevo;
        nuevo->anterior = cola;
        cola = nuevo;
    }
}
//Buscar por nombre
Nodo* ListaDoble::buscarPorNombre(const string &nombre) {
    Nodo* actual = cabeza;
    string nombreBuscado = aMinusculas(nombre);
    while (actual != nullptr) {
        if (aMinusculas(actual->nombre) == nombreBuscado) {
            return actual;
        }
        actual = actual->siguiente;
    }
    return nullptr;
}

// Buscar por habitación
Nodo* ListaDoble::buscarPorHabitacion(int habitacion) {
    Nodo* actual = cabeza;
    while (actual) {
        if (actual->numeroHabitacion == habitacion) return actual;
        actual = actual->siguiente;
    }
    return nullptr;
}

// Verificar si habitación está ocupada
bool ListaDoble::habitacionOcupada(int habitacion) {
    return buscarPorHabitacion(habitacion) != nullptr;
}

// Mostrar por llegada
void ListaDoble::mostrarPorLlegada() {
    if (!cabeza) {
        cout << "Lista vacía.\n";
        return;
    }
    Nodo* actual = cabeza;
    while (actual) {
        cout << "Huesped: " << actual->nombre
             << " | Habitacion: " << actual->numeroHabitacion << "\n";
        actual = actual->siguiente;
    }
}

// Mostrar en orden alfabético (burbuja)
void ListaDoble::mostrarAlfabetico() {
    if (!cabeza) {
        cout << "Lista vacia.\n";
        return;
    }
    // Copiar nodos en arreglo simple
    Nodo* nodos[100];
    int n = 0;
    Nodo* actual = cabeza;
    while (actual) {
        nodos[n++] = actual;
        actual = actual->siguiente;
    }
    // Orden burbuja
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            if (aMinusculas(nodos[j]->nombre) > aMinusculas(nodos[j+1]->nombre)) {
                Nodo* temp = nodos[j];
                nodos[j] = nodos[j+1];
                nodos[j+1] = temp;
            }
        }
    }

    // Mostrar
    for (int i = 0; i < n; i++) {
        cout << "Huesped: " << nodos[i]->nombre
             << " | Habitacion: " << nodos[i]->numeroHabitacion << "\n";
    }
}

// Consultar vecinos
void ListaDoble::consultarVecinos(int habitacion) {
    Nodo* anterior = nullptr;
    Nodo* siguiente = nullptr;

    Nodo* actual = cabeza;
    while (actual != nullptr) {
        // Buscar el vecino anterior (habitacion menor mas cercana)
        if (actual->numeroHabitacion < habitacion) {
            if (anterior == nullptr || actual->numeroHabitacion > anterior->numeroHabitacion) {
                anterior = actual;
            }
        }
        // Buscar el vecino siguiente (habitacion mayor mas cercana)
        else if (actual->numeroHabitacion > habitacion) {
            if (siguiente == nullptr || actual->numeroHabitacion < siguiente->numeroHabitacion) {
                siguiente = actual;
            }
        }
        actual = actual->siguiente;
    }

    if (anterior) {
        cout << "Vecino anterior: " << anterior->nombre
             << " (Hab " << anterior->numeroHabitacion << ")\n";
    } else {
        cout << "No hay vecino anterior.\n";
    }

    if (siguiente) {
        cout << "Vecino siguiente: " << siguiente->nombre
             << " (Hab " << siguiente->numeroHabitacion << ")\n";
    } else {
        cout << "No hay vecino siguiente.\n";
    }
}
// Cargar desde archivo
void ListaDoble::cargarDesdeArchivo(const string &nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo) return;
    string nombre, linea;
    int habitacion;
    while (getline(archivo, nombre) && getline(archivo, linea)) {
        stringstream ss(linea);
        ss >> habitacion;
        insertarHuesped(nombre, habitacion);
    }
    archivo.close();
}

// Guardar en archivo
void ListaDoble::guardarEnArchivo(const string &nombreArchivo) {
    ofstream archivo(nombreArchivo);
    Nodo* actual = cabeza;
    while (actual) {
        archivo << actual->nombre << "\n";
        archivo << actual->numeroHabitacion << "\n";
        actual = actual->siguiente;
    }
    archivo.close();
}


