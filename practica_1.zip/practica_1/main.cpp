#include <iostream>
#include "ListaDoble.h"
using namespace std;

int main() {
    ListaDoble hotel;
    string archivo = "hotel.txt";

    // Cargar datos al iniciar
    hotel.cargarDesdeArchivo(archivo);

    int opcion;
    do {
        cout << "\n===== MENU HOTEL =====\n";
        cout << "1. Ingresar nuevo huesped\n";
        cout << "2. Buscar huesped por nombre\n";
        cout << "3. Buscar huesped por habitacion\n";
        cout << "4. Mostrar lista por llegada\n";
        cout << "5. Mostrar lista alfabetica\n";
        cout << "6. Consultar vecinos\n";
        cout << "0. Salir\n";
        cout << "Ingrese opcion: ";
        cin >> opcion;
        cin.ignore();

        if (opcion == 1) {
            string nombre;
            int habitacion;
            cout << "Ingrese el nombre del huesped (sin tildes ni enes): ";
            getline(cin, nombre);
            cout << "Numero de habitacion: ";
            cin >> habitacion;
            cin.ignore();

            if (hotel.habitacionOcupada(habitacion)) {
                cout << "La habitacion " << habitacion << " esta ocupada.\n";
                // Sugerir anterior
                if (!hotel.habitacionOcupada(habitacion - 1) && habitacion > 1) {
                    cout << "Sugerencia: Habitacion " << habitacion - 1 << " disponible.\n";
                }
                // Sugerir siguiente
                else if (!hotel.habitacionOcupada(habitacion + 1)) {
                    cout << "Sugerencia: Habitacion " << habitacion + 1 << " disponible.\n";
                }
                else {
                    cout << "No hay habitaciones vecinas disponibles. Elija otra.\n";
                }
            }
            else {
                hotel.insertarHuesped(nombre, habitacion);
                hotel.guardarEnArchivo(archivo);
                cout << "Huesped registrado con exito.\n";
            }
        }
        else if (opcion == 2) {
            string nombre;
            cout << "Nombre del huesped (sin tildes ni enes): ";
            getline(cin, nombre);
            Nodo* encontrado = hotel.buscarPorNombre(nombre);
            if (encontrado) {
                cout << "Esta en la habitacion " << encontrado->numeroHabitacion << "\n";
            } else {
                cout << "Ese huesped no fue encontrado.\n";
            }
        }
        else if (opcion == 3) {
            int habitacion;
            cout << "Numero de habitacion: ";
            cin >> habitacion;
            cin.ignore();
            Nodo* encontrado = hotel.buscarPorHabitacion(habitacion);
            if (encontrado) {
                cout << "Huesped: " << encontrado->nombre << "\n";
            } else {
                cout << "No hay huesped en esa habitacion.\n";
            }
        }
        else if (opcion == 4) {
            hotel.mostrarPorLlegada();
        }
        else if (opcion == 5) {
            hotel.mostrarAlfabetico();
        }
        else if (opcion == 6) {
            int habitacion;
            cout << "Numero de habitacion: ";
            cin >> habitacion;
            cin.ignore();
            hotel.consultarVecinos(habitacion);
        }

    } while (opcion != 0);

    cout << "Saliendo del sistema...\n";
    return 0;
}


// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.