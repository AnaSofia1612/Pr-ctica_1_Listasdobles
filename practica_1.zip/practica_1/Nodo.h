#ifndef NODO_H
#define NODO_H

#include <string>  // Para usar std::string

// Clase que representa a un huésped en el hotel
class Nodo {
public:
    std::string nombre;   // Nombre del huésped
    int numeroHabitacion; // Número de habitación del huésped

    Nodo* anterior; // Puntero al nodo anterior en la lista
    Nodo* siguiente; // Puntero al siguiente nodo en la lista

    // Constructor
    Nodo(const std::string &nombreHuesped, int habitacion);
};

#endif // NODO_H


