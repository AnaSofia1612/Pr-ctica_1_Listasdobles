#include "Nodo.h"

// Constructor que inicializa los datos del huésped y deja punteros en nullptr
Nodo::Nodo(const std::string &nombreHuesped, int habitacion) {
    nombre = nombreHuesped;
    numeroHabitacion = habitacion;
    anterior = nullptr;
    siguiente = nullptr;
}
